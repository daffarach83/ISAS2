/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heapsort;
import java.util.Scanner;

/**
 *
 * @author Office
 */
public class HeapSort {

    public void sort(int arr[]) {
      int n = arr.length;
  
      // Build max heap
      for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
      }
  
      // Heap sort
      for (int i = n - 1; i >= 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
  
        // Heapify root element
        heapify(arr, i, 0);
      }
    }
  
    void heapify(int arr[], int n, int i) {
      // Find largest among root, left child and right child
      int largest = i;
      int l = 2 * i + 1;
      int r = 2 * i + 2;
  
      if (l < n && arr[l] > arr[largest])
        largest = l;
  
      if (r < n && arr[r] > arr[largest])
        largest = r;
  
      // Swap and continue heapifying if root is not largest
      if (largest != i) {
        int swap = arr[i];
        arr[i] = arr[largest];
        arr[largest] = swap;
  
        heapify(arr, n, largest);
      }
    }
  
    // Function to print an array
    static void printArray(int arr[]) {
      int n = arr.length;
      for (int i = 0; i < n; ++i)
        System.out.print(arr[i] + " ");
      System.out.println();
    }
    public static void main(String[] args) { 
      Scanner sc = new Scanner(System.in);
      char loop;
      do {
      System.out.println("Implementation of heap sort as Students score sorting");    
      System.out.print("How many student scores do you want to input : ");
      int size = sc.nextInt();
      int [] array = new int [size];
      for(int i=0;i<size;i++){
          System.out.print("Enter student grades : ");
          array[i] = sc.nextInt();
      }
      HeapSort hs = new HeapSort();
      hs.sort(array);
      
      System.out.println("Sorted score from lowest to highest");
      printArray(array); 
      
      System.out.print("Loop? (y/n) : ");
      loop = sc.next().charAt(0);
      
      }while(loop =='y'||loop =='n');
      sc.close();
      
      }
      }
